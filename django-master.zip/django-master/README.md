# django
Manish Django projects.
- Adding Anant's Django code.
