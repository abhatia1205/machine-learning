from django.apps import AppConfig


class DataentryConfig(AppConfig):
    name = 'dataentry'
